/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methodadaptercalculadora;

/**
 *
 * @author fernando
 */
public class ResultadoHexadecimal implements InterfaceAdapter {

    @Override
    public String converterResultado(String resultado) {
       return Double.toHexString(Double.valueOf(resultado));
    }
    
}
