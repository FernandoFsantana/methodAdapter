/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methodadaptercalculadora;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author fernando
 */
public class FXMLcalculadoraController implements Initializable {

    double valor1 = 0;
    double valor2 = 0;
    double resultado = 0;
    
   private InterfaceAdapter classeAdapter;
    
    String operacao = "";
    
    @FXML
    private Button btnC;
    @FXML
    private Button btnAC;  
    @FXML
    private TextField telaHistorico;
    @FXML
    private TextField telaResultadoTotalTextFild;
    @FXML
    private Button btn1;
    @FXML
    private Button btn4;
    @FXML
    private Button btn0;
    @FXML
    private Button btn7;
    @FXML
    private Button btn8;
    @FXML
    private Button btnPonto;
    @FXML
    private Button btn5;
    @FXML
    private Button btn2;
    @FXML
    private Button btn9;
    @FXML
    private Button btnIgual;
    @FXML
    private Button btn6;
    @FXML
    private Button btn3;
    @FXML
    private Button btnSubtracao;
    @FXML
    private Button btnSoma;
    @FXML
    private Button btnMultiplicacao;
    @FXML
    private Button btnDivisao;
    @FXML
    private Button btnClickHexadecimal;
    @FXML
    private Button btnClickOctal;
    @FXML
    private Button btnClickBinario;
    @FXML
    private TextField telaResultadoHexadecimal;
    @FXML
    private TextField telaResultadoOctal;
    @FXML
    private TextField telaResultadoBinario;
    
    @FXML
    public void resultadoBinario() {
        classeAdapter = new ResultadoBinario();
        telaResultadoBinario.setText(classeAdapter.converterResultado(String.valueOf(telaResultadoTotalTextFild.getText())));
    }
    @FXML
    public void resultadoOctal() {
        classeAdapter = new ResultadoOctal();
        telaResultadoOctal.setText(classeAdapter.converterResultado(String.valueOf(telaResultadoTotalTextFild.getText())));
    }
    @FXML
    public void resultadoHexadecimal() {
        classeAdapter = new ResultadoHexadecimal();
        telaResultadoHexadecimal.setText(classeAdapter.converterResultado(String.valueOf(telaResultadoTotalTextFild.getText())));
    }
    
    

    /**
     * Initializes the controller class.
     * @param url
     */
    public void initialize(URL url, ResourceBundle rb) {
      
        
        
       btn0.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"0");
                           telaHistorico.setText(telaHistorico.getText()+"0");

           }
       });
              btn1.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"1");
                           telaHistorico.setText(telaHistorico.getText()+"1");
                           

           }
       });
              btn2.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"2");
                           telaHistorico.setText(telaHistorico.getText()+"2");

           }
       });
           btn3.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"3");
                           telaHistorico.setText(telaHistorico.getText()+"3");

           }
       }); 
           btn4.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"4");
                           telaHistorico.setText(telaHistorico.getText()+"4");

           }
       });
           btn5.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"5");
                           telaHistorico.setText(telaHistorico.getText()+"5");

           }
       });
           btn6.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"6");
                           telaHistorico.setText(telaHistorico.getText()+"6");

           }
       });
           btn7.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"7");
                           telaHistorico.setText(telaHistorico.getText()+"7");

           }
       });
           btn8.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"8");
                           telaHistorico.setText(telaHistorico.getText()+"8");

           }
       });
           btn9.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+"9");
                           telaHistorico.setText(telaHistorico.getText()+"9");

           }
       });
           btnPonto.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                           telaResultadoTotalTextFild.setText(telaResultadoTotalTextFild.getText()+".");
                           telaHistorico.setText(telaHistorico.getText()+".");
           }
       });
           btnSoma.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
               valor1 = Double.parseDouble(telaResultadoTotalTextFild.getText());
               telaHistorico.setText(telaHistorico.getText()+"+");
                
               telaResultadoTotalTextFild.setText("");
               operacao = "+";
               
           }
       });
            btnSubtracao.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
               valor1 = Double.parseDouble(telaResultadoTotalTextFild.getText());
               telaHistorico.setText(telaHistorico.getText()+"-");
                
               telaResultadoTotalTextFild.setText("");
               operacao = "-";
               
           }
       });
             btnMultiplicacao.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
               valor1 = Double.parseDouble(telaResultadoTotalTextFild.getText());
               telaHistorico.setText(telaHistorico.getText()+"*");
                
               telaResultadoTotalTextFild.setText("");
               operacao = "*";
               
           }
       });
              btnDivisao.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
               valor1 = Double.parseDouble(telaResultadoTotalTextFild.getText());
               telaHistorico.setText(telaHistorico.getText()+"/");
                
               telaResultadoTotalTextFild.setText("");
               operacao = "/";
               
           }
       });
              btnC.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
              telaResultadoTotalTextFild.setText("");
              valor1=0;
              valor2=0;
              operacao = "";
              telaHistorico.setText("");
           }
       });
              btnIgual.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
            valor2 = Double.parseDouble(telaResultadoTotalTextFild.getText());
            telaHistorico.setText(telaHistorico.getText()+" = ");
            
            switch(operacao){
            
                case"+":
                    resultado=valor1+valor2;
                    telaResultadoTotalTextFild.setText(String.valueOf(resultado));
                    telaHistorico.setText(telaHistorico.getText()+" "+resultado);
                    break;
                   
                case"-":
                    resultado=valor1-valor2;
                    telaResultadoTotalTextFild.setText(String.valueOf(resultado));
                    telaHistorico.setText(telaHistorico.getText()+" "+resultado);
                    break;
                    
                case"*":    
                    resultado=valor1*valor2;
                    telaResultadoTotalTextFild.setText(String.valueOf(resultado));
                    telaHistorico.setText(telaHistorico.getText()+" "+resultado);
                    break;
                
                case"/": 
                    if(valor2 == 0){
                        telaResultadoTotalTextFild.setText("Não existe divisão por zero");
                    }else{
                    resultado=valor1/valor2;
                    telaResultadoTotalTextFild.setText(String.valueOf(resultado));
                    telaHistorico.setText(telaHistorico.getText()+" "+resultado);
                    break;
                    }
            }
           }
       });
        
    }    
    
}
